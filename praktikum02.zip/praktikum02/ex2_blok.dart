//blok program

void main(List<String>args){
  int a = 9;
  if(a>0){
    print('nilai a: $a');
    print('a adalah nilai positif');
  }
  int i = 0;
  while(i<a){
    print('baris ke-$i');
    i++;
  }
}