//tipe logika boolean
void main(List<String> args) {
  bool ganjil;
  num bilangan = 3;
  
  if (bilangan % 2 == 0) {
    ganjil = false;
  } else {
    ganjil = true;
  }

  print('Bilangan adalah ganjil $ganjil');
}
