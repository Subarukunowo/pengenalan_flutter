//menampilkan data ke layar
void main(List<String> args) {
  String prodi = 'Rekayasa Perangkat Lunak';
  String jurusan = 'Teknik Informatika';
  var myVar = 2;
  List myList = [1, 2, 3, 'b'];
  Map myMap = {1: 'Satu', 2: 'Dua', 3: 'Tiga'};

  print(prodi);
  print(jurusan);
  print(myVar);
  print(myVar == 2);
  print(myList);
  print(myMap);
}
