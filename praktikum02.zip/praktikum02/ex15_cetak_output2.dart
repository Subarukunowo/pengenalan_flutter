//menggunakan fungsi write() dan writeln()
import 'dart:io';

void main(List<String> args) {
  stdout.write('Rekayasa ');
  stdout.writeln('Perangkat Lunak');
  stdout.writeln('Jurusan Teknik Informatika');
  stdout.writeln('Politeknik Negeri Bengkalis');
}

