//contoh komentar
void main(List<String>args){
  //komentar satu baris
  //ini komentar kedua
  /*
  ** komentar lebih dari 
 ** ok
 */
/// komentar untuk dokumentasi
/// 
/// komentar ini digunakan untuk mendokumentasi sintaks program 
}