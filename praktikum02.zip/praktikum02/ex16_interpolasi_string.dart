//interpolasi string $
void main(List<String> args) {
  var a = 2;
  var b = 3;
  var c = 'Nilai a = $a dan b = $b';
  var d = 'Dart';

  print('Interpolasi string dalam ${d.toUpperCase()}!');
  print(c);
}
