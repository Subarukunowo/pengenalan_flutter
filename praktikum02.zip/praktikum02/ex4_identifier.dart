//pengenal (identifier)
void main(List<String>args){
   String nama_depan;  
  double dimensi2;   
  var tanda = '#';   
}