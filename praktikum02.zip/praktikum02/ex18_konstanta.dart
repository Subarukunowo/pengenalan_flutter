//konstanta
void main(List<String> args) {
  final String BAHASA = 'Dart';
  final VERSI = '2.1.0';
  const double PI = 3.14159;
  const MAX = 100;
  
  print('$BAHASA $VERSI');
  print('Nilai PI: $PI');
  print('Nilai MAX: $MAX');
}
