//statement

void main(List<String> args){
  print('pemrograman android');
  print('Menggunakan Dart dan FLutter');
  int a, b,   c;
  String strA = "A";
  double d; int i;
}